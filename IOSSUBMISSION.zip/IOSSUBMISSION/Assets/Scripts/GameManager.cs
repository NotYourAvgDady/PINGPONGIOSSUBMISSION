using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO; // file operations

public class GameManager : MonoBehaviour
{
    [Header("Scores")]
    [SerializeField] int playerScore;
    [SerializeField] int opponentScore;

    [Header("UI")]
    [SerializeField] TMP_Text playerScoreText;
    [SerializeField] TMP_Text opponentScoreText;
    [SerializeField] GameObject gameOverPanel;
    [SerializeField] TMP_Text gameOverText;
    [SerializeField] GameObject leaderBoardPanel;

    public BallController BallController;

    private string filePath;
    private PlayerScores gameScores;

    public LeaderBoardManager LeaderBoardManager;

    [Header("LeaderBoardManager")]
    [SerializeField] int winningScore;

    private bool isGameOver = false;

    void Start()
    {
        filePath = Application.persistentDataPath + "/scores.json";

        if(gameOverPanel != null)
        {
            gameOverPanel.SetActive(false); 
        }

        if(leaderBoardPanel != null)
        {
            leaderBoardPanel.SetActive(false);
        }
    }

    public void SaveScores()
    {
        string json = JsonUtility.ToJson(playerScore, true); 

        Debug.Log("Saving JSON: " + json); 

        string path = Application.persistentDataPath + "/scoreData.json";
        File.WriteAllText(path, json);  
        Debug.Log("Data saved to: " + path);
    }

    public void LoadScores()
    {
        if(File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            gameScores = JsonUtility.FromJson<PlayerScores>(json);
        }
        else
        {
            gameScores = new PlayerScores { playerScore = 0, opponentScore = 0};
            Debug.Log("No Scores file Found");
        }
    }

    public PlayerScores GetScores()
    {
        return gameScores;
    }

    public void UpdateScores(bool PlayerScored)
    {
        if (PlayerScored)
        {
            playerScore++;
        }
        else
        {
            opponentScore++;
        }

        playerScoreText.text = "Enemy: " + playerScore.ToString();
        opponentScoreText.text = "Player: " + opponentScore.ToString();

        SaveScores();
    }

    public void PlayerScored()
    {
        BallController.BallReset();
        UpdateScores(true);
        Debug.Log("PlayerScored");
        CheckGameOver();
    } 
    
    public void OpponentScored()
    {
        BallController.BallReset();
        UpdateScores(false);
        Debug.Log("EnemyScored");
        CheckGameOver();
    }

    void UpdateScoreText()
    {
        playerScoreText.text = playerScore.ToString();
        opponentScoreText.text = opponentScore.ToString();
    }

    void CheckGameOver()
    {
        if (isGameOver) return;

        if(playerScore >= winningScore || opponentScore >= winningScore)
        {
            isGameOver = true;
            ShowGameOverScreen();
        }
    }

    void ShowGameOverScreen()
    {
        if(gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
            gameOverText.text = playerScore >= winningScore
                ? "Player Wins"
                : "Enemy Wins";
        }

        Debug.Log(playerScore >= winningScore ? "Player Wins!" : "Enemy Wins!");

        //BallController.DisableBall();

        LeaderBoardManager.AddScore("Player", playerScore);
        LeaderBoardManager.AddScore("Enemy", opponentScore);

        LeaderBoardUI leaderboardUI = FindObjectOfType<LeaderBoardUI>();

        leaderboardUI.DisplayLeaderBoard();

        if (LeaderBoardManager == null)
        {
            LeaderBoardManager = FindObjectOfType<LeaderBoardManager>(); 
        }

        if (LeaderBoardManager != null)
        {
            LeaderBoardManager.AddScore("Player", playerScore);
        }

        StartCoroutine(RestartGameAfterDelay(5f));

        IEnumerator RestartGameAfterDelay(float delay)
        {
            yield return new WaitForSeconds(delay);
            RestartGame();
        }

        StartCoroutine(ShowLeaderBoard(1f));

        IEnumerator ShowLeaderBoard(float delay)
        {
            yield return new WaitForSeconds(delay);
            if (leaderBoardPanel != null)
            {
                leaderBoardPanel.SetActive(true); 
            }
            if (gameOverPanel != null)
            {
                gameOverPanel.SetActive(false);  
            }
        }
    }

    public void RestartGame()
    {
        isGameOver = false;
        playerScore = 0;
        opponentScore = 0;
        playerScoreText.text = "Player: 0";
        opponentScoreText.text = "Enemy: 0";
        gameOverPanel.SetActive(false);

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);  
        }
        if (leaderBoardPanel != null)
        {
            leaderBoardPanel.SetActive(false);  
        }

        BallController.BallReset();
    }
}
