using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
    public GameManager GameManager;

    [Header("Movement")]
    [SerializeField] float initialSpeed = 5f;
    [SerializeField] Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        BallReset();
        //rb.velocity = new Vector2(Random.Range(-1f, 1f) , Random.Range(-1f, 1f)).normalized * initialSpeed;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Vector2 reflectBack = Vector2.Reflect(rb.velocity, collision.contacts[0].normal);

        reflectBack.Normalize();

        //float angleVariation = Random.Range(-0.1f, 0.1f);
        //reflectBack.x += angleVariation;

        rb.velocity = reflectBack.normalized * initialSpeed;
    }

    public void BallReset()
    {
        rb.velocity = Vector2.zero;

        transform.position = Vector3.zero;

        StartCoroutine(Relaunch());
    }

    IEnumerator Relaunch()
    {
        yield return new WaitForSeconds(.5f);

        float x = Random.Range(0,2) == 0 ? -1 : 1;
        float y = Random.Range(0,2) == 0 ? -1 : 1;

        rb.velocity = new Vector2(x,y).normalized * initialSpeed;
        //rb.velocity = new Vector2(Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized * initialSpeed;


    }

}
