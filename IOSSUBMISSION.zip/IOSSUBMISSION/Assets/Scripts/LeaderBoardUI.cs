using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class LeaderBoardUI : MonoBehaviour
{

    public TextMeshProUGUI leaderboardText;
    public LeaderBoardManager LeaderBoardManager;


    void Start()
    {
        DisplayLeaderBoard();
    }

    public void DisplayLeaderBoard()
    {
        leaderboardText.text = "LeaderBoard\n";

        LeaderBoardManager.LoadLeaderBoard();

        foreach (var data in LeaderBoardManager.leaderBoard.topScore)
        {
            leaderboardText.text += data.playerName + ": " + data.score + "\n";
        }
    }
}
